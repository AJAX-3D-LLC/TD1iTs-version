This is a placeholder firmware ZIP.
Replace downloads/TD1_Firmware_v1.0.4.zip with the real TD1 firmware update.zip.
